export const hi = '你好';
let b = 20;
let c = 'hello';
console.log(b, c);