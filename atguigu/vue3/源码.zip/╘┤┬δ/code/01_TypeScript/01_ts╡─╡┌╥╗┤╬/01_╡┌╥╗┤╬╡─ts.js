(function () {
    // str这个参数是string类型的
    function sayHi(str) {
        return '您好啊' + str;
    }
    var text = '小甜甜';
    console.log(sayHi(text));
})();
