import './01_基础类型'
document.write('哈哈,我又变帅了!!!')