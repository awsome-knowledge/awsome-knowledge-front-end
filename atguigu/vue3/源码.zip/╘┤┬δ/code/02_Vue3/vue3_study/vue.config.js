// vue.config.js
module.exports = {
  // 选项...
  lintOnSave:false // 关闭eslint语法检查
}